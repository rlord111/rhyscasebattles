# Rhys Coin Casino

A crypto-powered casino site built for RhysCoin (RHC).

## Pages
- Coin Flip
- Blackjack
- Roulette
- Case Opening
- Poker
- Player Profile

## Deployment
1. Upload all files to GitHub.
2. Import to Vercel.
3. Set Coinbase CHECKOUT_ID in coinbase.js
